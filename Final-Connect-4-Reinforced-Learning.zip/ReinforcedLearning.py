##################################
#   Reinforced Learning Class    #
##################################
# This class holds all the methods for Reinforcement Learning Implimentation