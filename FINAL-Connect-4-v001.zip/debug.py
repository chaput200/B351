# use this file to write simple debugging methods for each function after implimentation
# remember to change what file is ran with the "RUN" button by editing the .replit file

